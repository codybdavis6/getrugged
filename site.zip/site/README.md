# Site

`site/` is now the root website area.

The shareable PnL app lives in:

```text
site/pnl/
```

Open the PnL app locally:

```text
site/pnl/index.html#/pnl/demo
```

Useful PnL routes:

```text
#/pnl/demo
#/pnl/custom-id?profit=8.28&invested=9&multiplier=0.92&mode=Sniper%20Dump&currency=SOL&token=$SNIPER&scope=All%20Wallets
#/pnl/wallet1?profit=1.14&invested=0.5&mode=Wallet%201%20Exit
```

Expected public route:

```text
https://site.com/#/pnl/your-special-id
```

Bot integration:

- keep `PNL_SITE_URL=https://site.com/`
- keep `PNL_SITE_DOMAIN=site.com`
- the bot will generate links in the `#/pnl/<id>` format
