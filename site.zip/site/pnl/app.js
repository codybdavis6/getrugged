const DEMO_PROFILES = {
  demo: {
    pnl: "demo",
    domain: "getrugged.com",
    profit: 8.28,
    invested: 9,
    multiplier: 0.92,
    mode: "Sniper Dump",
    currency: "SOL",
    token: "$SNIPER",
    scope: "All Wallets",
  },
  wallet1: {
    pnl: "wallet1",
    domain: "getrugged.com",
    profit: 1.14,
    invested: 0.5,
    multiplier: 2.28,
    mode: "Wallet 1 Exit",
    currency: "SOL",
    token: "$SNIPER",
    scope: "Wallet 1",
  },
};

const readRouteState = () => {
  const rawHash = window.location.hash.startsWith("#")
    ? window.location.hash.slice(1)
    : window.location.hash;
  const [rawPath = "", rawQuery = ""] = rawHash.split("?");
  const routeSegments = rawPath.split("/").filter(Boolean);
  const pnlId = routeSegments[0] === "pnl" && routeSegments[1]
    ? decodeURIComponent(routeSegments[1])
    : undefined;

  return {
    pnlId,
    params: new URLSearchParams(rawQuery),
  };
};

const readParams = () => {
  const searchParams = new URLSearchParams(window.location.search);
  const routeState = readRouteState();
  const merged = new URLSearchParams(searchParams);

  for (const [key, value] of routeState.params.entries()) {
    merged.set(key, value);
  }

  return {
    params: merged,
    pnlId: routeState.pnlId,
  };
};

const readNumber = (params, key, fallback) => {
  const value = params.get(key);
  if (value === null || value.trim() === "") {
    return fallback;
  }

  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
};

const formatAmount = (value) => {
  const decimals = Math.abs(value) >= 1 ? 2 : 4;
  return Number(value).toFixed(decimals).replace(/\.?0+$/, "");
};

const resolveProfile = () => {
  const { params, pnlId } = readParams();
  const requestedId = pnlId || params.get("pnl") || "demo";
  const baseProfile = DEMO_PROFILES[requestedId] || DEMO_PROFILES.demo;

  const profit = readNumber(params, "profit", baseProfile.profit);
  const invested = readNumber(params, "invested", baseProfile.invested);
  const multiplier =
    readNumber(
      params,
      "multiplier",
      invested > 0 ? Math.abs(profit / invested) : baseProfile.multiplier,
    ) || 0;

  return {
    pnl: requestedId,
    domain: params.get("domain") || baseProfile.domain,
    profit,
    invested,
    multiplier,
    mode: params.get("mode") || baseProfile.mode,
    currency: (params.get("currency") || baseProfile.currency || "SOL").toUpperCase(),
    token: params.get("token") || baseProfile.token,
    scope: params.get("scope") || baseProfile.scope,
  };
};

const render = () => {
  const profile = resolveProfile();
  const isNegative = profile.profit < 0;
  const root = document.documentElement;

  root.classList.toggle("negative", isNegative);

  document.getElementById("domainLabel").textContent = profile.domain;
  document.getElementById("profitSign").textContent = isNegative ? "-" : "+";
  document.getElementById("profitValue").textContent = formatAmount(Math.abs(profile.profit));
  document.getElementById("profitCurrency").textContent = profile.currency;
  document.getElementById("multipleValue").textContent = `${formatAmount(profile.multiplier)}X`;
  document.getElementById("investedValue").textContent = `${formatAmount(profile.invested)} ${profile.currency}`;
  document.getElementById("profitCardValue").textContent = `${formatAmount(Math.abs(profile.profit))} ${profile.currency}`;
  document.getElementById("modeValue").textContent = profile.mode;
  document.getElementById("tokenValue").textContent = profile.token;
  document.getElementById("scopeValue").textContent = profile.scope;
  document.getElementById("pnlIdValue").textContent = profile.pnl;
  const statusHint = document.getElementById("statusHint");
  if (statusHint) {
    statusHint.innerHTML = `Live preview from <code>${window.location.hash || "#/pnl/demo"}</code>`;
  }
  document.title = `${profile.token} PnL | GetRugged`;
};

const setupCopyButton = () => {
  const button = document.getElementById("copyLinkButton");

  button.addEventListener("click", async () => {
    try {
      await navigator.clipboard.writeText(window.location.href);
      button.textContent = "Link Copied";
      window.setTimeout(() => {
        button.textContent = "Copy PnL Link";
      }, 1800);
    } catch {
      button.textContent = "Copy Failed";
      window.setTimeout(() => {
        button.textContent = "Copy PnL Link";
      }, 1800);
    }
  });
};

window.addEventListener("hashchange", render);
window.addEventListener("DOMContentLoaded", () => {
  render();
  setupCopyButton();
});
