const body = document.body;
const siteShell = document.getElementById("siteShell");
const pnlRouteShell = document.getElementById("pnlRouteShell");
const pnlFrame = document.getElementById("pnlFrame");
const menuToggle = document.getElementById("menuToggle");
const menuClose = document.getElementById("menuClose");
const menuOverlay = document.getElementById("menuOverlay");
const menuPanel = document.getElementById("menuPanel");
const menuLinks = document.querySelectorAll(".menu-link, .menu-cta");
const keypad = document.getElementById("keypad");

const isPnlRoute = () => /^#\/pnl(?:\/|$)/.test(window.location.hash);

const closeMenu = () => {
  body.classList.remove("nav-open");
  menuToggle?.setAttribute("aria-expanded", "false");
  menuPanel?.setAttribute("aria-hidden", "true");
  if (menuOverlay) {
    menuOverlay.hidden = true;
  }
};

const openMenu = () => {
  body.classList.add("nav-open");
  menuToggle?.setAttribute("aria-expanded", "true");
  menuPanel?.setAttribute("aria-hidden", "false");
  if (menuOverlay) {
    menuOverlay.hidden = false;
  }
};

const syncRouteView = () => {
  const showingPnl = isPnlRoute();

  if (showingPnl) {
    closeMenu();
    siteShell.hidden = true;
    pnlRouteShell.hidden = false;

    const targetSrc = `./pnl/index.html${window.location.hash}`;
    if (pnlFrame.getAttribute("src") !== targetSrc) {
      pnlFrame.setAttribute("src", targetSrc);
    }

    return;
  }

  pnlRouteShell.hidden = true;
  siteShell.hidden = false;
};

const setupMenu = () => {
  menuToggle?.addEventListener("click", () => {
    if (body.classList.contains("nav-open")) {
      closeMenu();
      return;
    }

    openMenu();
  });

  menuClose?.addEventListener("click", closeMenu);
  menuOverlay?.addEventListener("click", closeMenu);

  menuLinks.forEach((link) => {
    link.addEventListener("click", closeMenu);
  });

  window.addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
      closeMenu();
    }
  });
};

const setupKeypadMotion = () => {
  if (!keypad || window.matchMedia("(max-width: 820px)").matches) {
    return;
  }

  const updateTilt = (event) => {
    const bounds = keypad.getBoundingClientRect();
    const offsetX = (event.clientX - bounds.left) / bounds.width - 0.5;
    const offsetY = (event.clientY - bounds.top) / bounds.height - 0.5;

    keypad.style.setProperty("--tilt-x", `${offsetY * -7}deg`);
    keypad.style.setProperty("--tilt-y", `${offsetX * 9}deg`);
  };

  keypad.addEventListener("mousemove", updateTilt);
  keypad.addEventListener("mouseleave", () => {
    keypad.style.setProperty("--tilt-x", "0deg");
    keypad.style.setProperty("--tilt-y", "0deg");
  });
};

window.addEventListener("hashchange", syncRouteView);
window.addEventListener("DOMContentLoaded", () => {
  body.classList.add("is-ready");
  setupMenu();
  setupKeypadMotion();
  syncRouteView();
});
